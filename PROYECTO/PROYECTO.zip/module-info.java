/**
 * 
 */
/**
 * 
 */
module PROYECTO {
	
	requires junit;
	exports Practica;
	
	
}